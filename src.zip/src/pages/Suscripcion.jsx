import React from 'react'

export default function Suscripcion() {
  return (
    <div>Suscripcion</div>
  )
}
