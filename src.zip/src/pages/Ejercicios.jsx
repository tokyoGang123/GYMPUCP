import React from 'react'

export default function Ejercicios() {
  return (
    <div>Ejercicios</div>
  )
}
