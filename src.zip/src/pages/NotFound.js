import React from "react";

const NotFound = () => {
  return (
    <div>
      <h1 className="not-found">Not found</h1>
    </div>
  );
};

export default NotFound;
