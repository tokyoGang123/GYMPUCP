export const MenuItems = [
  {
    title: "Username",
    path: "/",
    cName: "dropdown-link",
  },
  {
    title: "sign-out",
    path: "/sign-out",
    cName: "dropdown-link",
  },
];
